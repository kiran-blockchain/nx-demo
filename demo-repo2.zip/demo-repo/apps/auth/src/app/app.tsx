import { Button } from '@demo/ui';
import {Provider} from 'react-redux';
import { store } from '@demo/shared-redux';

function App() {
  return (
    <div>
      <h1>Auth App</h1>
      <Button variant="primary">Click me</Button>
    </div>
  );
}

export default App;