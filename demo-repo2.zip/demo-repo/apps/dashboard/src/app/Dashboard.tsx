// apps/dashboard/src/app/Dashboard.tsx
import { useEffect } from 'react';
import { useSelector } from '@demo/shared-redux';

export function Dashboard() {
  const user = useSelector((state) => state.user);

  useEffect(() => {
    // Only redirect if no user AND no stored state
    const storedState = localStorage.getItem('reduxState');
    const isAuthenticated = user.isAuthenticated || 
      (storedState && JSON.parse(storedState).user.isAuthenticated);

    // if (!isAuthenticated) {
    //   window.location.href = 'http://localhost:4200'; // Auth app port
    // }
  }, [user.isAuthenticated]);

  if (!user.isAuthenticated) {
    return <div>Loading...</div>; // Show loader while checking auth
  }

  return (
    <div>
      <h1>Welcome to Dashboard</h1>
      {/* Dashboard content */}
    </div>
  );
}