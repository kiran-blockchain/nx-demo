// // libs/shared/redux/src/lib/store.ts
// import { configureStore } from '@reduxjs/toolkit';
// import userReducer from './features/user/userSlice.js';

// export const store = configureStore({
//   reducer: {
//     user: userReducer,
//   },
// });

// // Export these types for use throughout your apps
// export type RootState = ReturnType<typeof store.getState>;
// export type AppDispatch = typeof store.dispatch;

// libs/shared/redux/src/lib/store.ts
import { configureStore } from '@reduxjs/toolkit';
import userReducer from './features/user/userSlice.js';

export const store = configureStore({
  reducer: {
    user: userReducer,
  },
});

// Add localStorage persistence
if (typeof window !== 'undefined') {
  // Load state
  const savedState = localStorage.getItem('reduxState');
  if (savedState) {
    store.dispatch({
      type: 'REHYDRATE',
      payload: JSON.parse(savedState),
    });
  }

  // Save state on changes
  store.subscribe(() => {
    const state = store.getState();
    localStorage.setItem('reduxState', JSON.stringify(state));
  });
}

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;