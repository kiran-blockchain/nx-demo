import { redux } from './redux.js';

describe('redux', () => {
  it('should work', () => {
    expect(redux()).toEqual('redux');
  });
});
