export function redux(): string {
  return 'redux';
}
